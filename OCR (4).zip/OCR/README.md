EPIREAD!
===================

EPITA S3 project made by Atomic Corp. / Project proposed by burell_m. 

Members :
* antoine.montes (MONTES Antoine)
* romain.wallez (WALLEZ Romain)
* gauthier.fiorentino (FIORENTINO Gauthier)
* borne_i (BORNE Ianis)


How to use EpiRead.
-------------
First type make in your terminal !                             
> - ./main without args to launch GUI                           
> - ./main (command) to use the program 
> - ./main --help to show commands 
