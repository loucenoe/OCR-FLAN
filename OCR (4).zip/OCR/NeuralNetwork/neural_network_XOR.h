// neural_network_XOR.h
 
# ifndef NEURAL_NETWORK_XOR_H_
# define NEURAL_NETWORK_XOR_H_
 
# include <SDL/SDL.h>
# include <err.h>
# include <stdio.h>
# include <stdlib.h>
# include <time.h>
# include <math.h>

//The call function
void XOR();

# endif